package com.example.p03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P03Application {

	public static void main(String[] args) {
		SpringApplication.run(P03Application.class, args);
	}

}
